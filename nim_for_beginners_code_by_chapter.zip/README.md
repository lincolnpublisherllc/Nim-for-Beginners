# Nim for Beginners — Code Extracts

- Source: Nim for Beginners.docx
- Extracted: 2025-09-19T06:23:53.574940Z

## What’s inside

Code snippets grouped per chapter. Filenames are generic (`snippet_###.ext`) with small tags to hint at content (e.g., `_proc`, `_nim`, `_echo`).

### Manifest

- **Chapter 01** (8 snippets)

  - `Chapter_01/snippet_001.txt` — txt (1 lines)

  - `Chapter_01/snippet_002.txt` — txt (1 lines)

  - `Chapter_01/snippet_003_c.c` — c (6 lines)

  - `Chapter_01/snippet_004_echo.nim` — nim (1 lines)

  - `Chapter_01/snippet_005_echo.nim` — nim (1 lines)

  - `Chapter_01/snippet_006_nim.sh` — sh (3 lines)

  - `Chapter_01/snippet_007.nim` — nim (1 lines)

  - `Chapter_01/snippet_008.txt` — txt (2 lines)

- **Chapter 02** (16 snippets)

  - `Chapter_02/snippet_001_curl.sh` — sh (1 lines)

  - `Chapter_02/snippet_002_nim.sh` — sh (3 lines)

  - `Chapter_02/snippet_003_nim.sh` — sh (1 lines)

  - `Chapter_02/snippet_004.sh` — sh (1 lines)

  - `Chapter_02/snippet_005.sh` — sh (1 lines)

  - `Chapter_02/snippet_006.sh` — sh (1 lines)

  - `Chapter_02/snippet_007_echo.nim` — nim (1 lines)

  - `Chapter_02/snippet_008_nim.sh` — sh (3 lines)

  - `Chapter_02/snippet_009.sh` — sh (2 lines)

  - `Chapter_02/snippet_010.sh` — sh (1 lines)

  - `Chapter_02/snippet_011.sh` — sh (2 lines)

  - `Chapter_02/snippet_012.sh` — sh (1 lines)

  - `Chapter_02/snippet_013.nim` — nim (6 lines)

  - `Chapter_02/snippet_014_nim.sh` — sh (1 lines)

  - `Chapter_02/snippet_015.txt` — txt (1 lines)

  - `Chapter_02/snippet_016.txt` — txt (3 lines)

- **Chapter 03** (13 snippets)

  - `Chapter_03/snippet_001_echo.nim` — nim (1 lines)

  - `Chapter_03/snippet_002_nim.sh` — sh (1 lines)

  - `Chapter_03/snippet_003.bat` — bat (2 lines)

  - `Chapter_03/snippet_004.txt` — txt (1 lines)

  - `Chapter_03/snippet_005_nim.sh` — sh (1 lines)

  - `Chapter_03/snippet_006_echo.nim` — nim (3 lines)

  - `Chapter_03/snippet_007.nim` — nim (4 lines)

  - `Chapter_03/snippet_008_nim.sh` — sh (1 lines)

  - `Chapter_03/snippet_009.txt` — txt (6 lines)

  - `Chapter_03/snippet_010.nim` — nim (1 lines)

  - `Chapter_03/snippet_011.txt` — txt (4 lines)

  - `Chapter_03/snippet_012.nim` — nim (1 lines)

  - `Chapter_03/snippet_013.txt` — txt (3 lines)

- **Chapter 04** (18 snippets)

  - `Chapter_04/snippet_001.txt` — txt (1 lines)

  - `Chapter_04/snippet_002.nim` — nim (3 lines)

  - `Chapter_04/snippet_003.nim` — nim (9 lines)

  - `Chapter_04/snippet_004.nim` — nim (3 lines)

  - `Chapter_04/snippet_005.nim` — nim (2 lines)

  - `Chapter_04/snippet_006.nim` — nim (4 lines)

  - `Chapter_04/snippet_007.txt` — txt (1 lines)

  - `Chapter_04/snippet_008.nim` — nim (3 lines)

  - `Chapter_04/snippet_009.txt` — txt (1 lines)

  - `Chapter_04/snippet_010_echo.nim` — nim (1 lines)

  - `Chapter_04/snippet_011.txt` — txt (2 lines)

  - `Chapter_04/snippet_012.nim` — nim (5 lines)

  - `Chapter_04/snippet_013.txt` — txt (1 lines)

  - `Chapter_04/snippet_014.nim` — nim (7 lines)

  - `Chapter_04/snippet_015.nim` — nim (3 lines)

  - `Chapter_04/snippet_016.txt` — txt (1 lines)

  - `Chapter_04/snippet_017.nim` — nim (1 lines)

  - `Chapter_04/snippet_018.txt` — txt (3 lines)

- **Chapter 05** (17 snippets)

  - `Chapter_05/snippet_001.nim` — nim (10 lines)

  - `Chapter_05/snippet_002.txt` — txt (1 lines)

  - `Chapter_05/snippet_003.nim` — nim (9 lines)

  - `Chapter_05/snippet_004.nim` — nim (6 lines)

  - `Chapter_05/snippet_005.nim` — nim (4 lines)

  - `Chapter_05/snippet_006.sh` — sh (1 lines)

  - `Chapter_05/snippet_007_echo.nim` — nim (2 lines)

  - `Chapter_05/snippet_008.nim` — nim (2 lines)

  - `Chapter_05/snippet_009.nim` — nim (2 lines)

  - `Chapter_05/snippet_010.txt` — txt (1 lines)

  - `Chapter_05/snippet_011.nim` — nim (2 lines)

  - `Chapter_05/snippet_012.txt` — txt (1 lines)

  - `Chapter_05/snippet_013.txt` — txt (1 lines)

  - `Chapter_05/snippet_014_echo.nim` — nim (2 lines)

  - `Chapter_05/snippet_015.txt` — txt (5 lines)

  - `Chapter_05/snippet_016.txt` — txt (1 lines)

  - `Chapter_05/snippet_017.txt` — txt (8 lines)

- **Chapter 06** (22 snippets)

  - `Chapter_06/snippet_001.txt` — txt (2 lines)

  - `Chapter_06/snippet_002.nim` — nim (10 lines)

  - `Chapter_06/snippet_003.txt` — txt (1 lines)

  - `Chapter_06/snippet_004.nim` — nim (10 lines)

  - `Chapter_06/snippet_005.nim` — nim (11 lines)

  - `Chapter_06/snippet_006.txt` — txt (1 lines)

  - `Chapter_06/snippet_007.nim` — nim (2 lines)

  - `Chapter_06/snippet_008.txt` — txt (5 lines)

  - `Chapter_06/snippet_009.nim` — nim (2 lines)

  - `Chapter_06/snippet_010.txt` — txt (3 lines)

  - `Chapter_06/snippet_011.nim` — nim (4 lines)

  - `Chapter_06/snippet_012.txt` — txt (3 lines)

  - `Chapter_06/snippet_013.nim` — nim (7 lines)

  - `Chapter_06/snippet_014.txt` — txt (4 lines)

  - `Chapter_06/snippet_015.nim` — nim (3 lines)

  - `Chapter_06/snippet_016.txt` — txt (5 lines)

  - `Chapter_06/snippet_017.nim` — nim (4 lines)

  - `Chapter_06/snippet_018.txt` — txt (4 lines)

  - `Chapter_06/snippet_019.nim` — nim (4 lines)

  - `Chapter_06/snippet_020.txt` — txt (4 lines)

  - `Chapter_06/snippet_021.txt` — txt (1 lines)

  - `Chapter_06/snippet_022.txt` — txt (4 lines)

- **Chapter 07** (22 snippets)

  - `Chapter_07/snippet_001_proc.nim` — nim (3 lines)

  - `Chapter_07/snippet_002.txt` — txt (1 lines)

  - `Chapter_07/snippet_003.txt` — txt (1 lines)

  - `Chapter_07/snippet_004_proc.nim` — nim (2 lines)

  - `Chapter_07/snippet_005.txt` — txt (2 lines)

  - `Chapter_07/snippet_006.txt` — txt (2 lines)

  - `Chapter_07/snippet_007_proc.nim` — nim (2 lines)

  - `Chapter_07/snippet_008.nim` — nim (2 lines)

  - `Chapter_07/snippet_009.txt` — txt (1 lines)

  - `Chapter_07/snippet_010_proc.nim` — nim (2 lines)

  - `Chapter_07/snippet_011.txt` — txt (2 lines)

  - `Chapter_07/snippet_012_proc.nim` — nim (2 lines)

  - `Chapter_07/snippet_013.txt` — txt (1 lines)

  - `Chapter_07/snippet_014.txt` — txt (1 lines)

  - `Chapter_07/snippet_015.nim` — nim (2 lines)

  - `Chapter_07/snippet_016.nim` — nim (1 lines)

  - `Chapter_07/snippet_017_proc.nim` — nim (6 lines)

  - `Chapter_07/snippet_018_proc.nim` — nim (7 lines)

  - `Chapter_07/snippet_019.txt` — txt (1 lines)

  - `Chapter_07/snippet_020.txt` — txt (1 lines)

  - `Chapter_07/snippet_021.txt` — txt (2 lines)

  - `Chapter_07/snippet_022.txt` — txt (3 lines)

- **Chapter 08** (17 snippets)

  - `Chapter_08/snippet_001.nim` — nim (1 lines)

  - `Chapter_08/snippet_002_echo.nim` — nim (2 lines)

  - `Chapter_08/snippet_003.nim` — nim (2 lines)

  - `Chapter_08/snippet_004.nim` — nim (1 lines)

  - `Chapter_08/snippet_005.nim` — nim (2 lines)

  - `Chapter_08/snippet_006.nim` — nim (2 lines)

  - `Chapter_08/snippet_007_echo.nim` — nim (1 lines)

  - `Chapter_08/snippet_008.nim` — nim (2 lines)

  - `Chapter_08/snippet_009.txt` — txt (2 lines)

  - `Chapter_08/snippet_010.nim` — nim (1 lines)

  - `Chapter_08/snippet_011.nim` — nim (3 lines)

  - `Chapter_08/snippet_012_echo.nim` — nim (1 lines)

  - `Chapter_08/snippet_013.nim` — nim (2 lines)

  - `Chapter_08/snippet_014.txt` — txt (2 lines)

  - `Chapter_08/snippet_015.nim` — nim (2 lines)

  - `Chapter_08/snippet_016.nim` — nim (7 lines)

  - `Chapter_08/snippet_017.txt` — txt (4 lines)

- **Chapter 09** (14 snippets)

  - `Chapter_09/snippet_001.nim` — nim (2 lines)

  - `Chapter_09/snippet_002_nim.sh` — sh (1 lines)

  - `Chapter_09/snippet_003.nim` — nim (4 lines)

  - `Chapter_09/snippet_004.nim` — nim (2 lines)

  - `Chapter_09/snippet_005_nim.sh` — sh (1 lines)

  - `Chapter_09/snippet_006.txt` — txt (1 lines)

  - `Chapter_09/snippet_007_proc.nim` — nim (8 lines)

  - `Chapter_09/snippet_008_nim.sh` — sh (1 lines)

  - `Chapter_09/snippet_009.txt` — txt (4 lines)

  - `Chapter_09/snippet_010_nim.sh` — sh (1 lines)

  - `Chapter_09/snippet_011.txt` — txt (1 lines)

  - `Chapter_09/snippet_012_nim.sh` — sh (2 lines)

  - `Chapter_09/snippet_013.txt` — txt (1 lines)

  - `Chapter_09/snippet_014.txt` — txt (1 lines)

- **Chapter 10** (18 snippets)

  - `Chapter_10/snippet_001.txt` — txt (28 lines)

  - `Chapter_10/snippet_002.nim` — nim (5 lines)

  - `Chapter_10/snippet_003.nim` — nim (6 lines)

  - `Chapter_10/snippet_004_proc.nim` — nim (10 lines)

  - `Chapter_10/snippet_005_proc.nim` — nim (9 lines)

  - `Chapter_10/snippet_006_proc.nim` — nim (5 lines)

  - `Chapter_10/snippet_007_proc.nim` — nim (15 lines)

  - `Chapter_10/snippet_008_proc.nim` — nim (14 lines)

  - `Chapter_10/snippet_009.nim` — nim (67 lines)

  - `Chapter_10/snippet_010_proc.nim` — nim (15 lines)

  - `Chapter_10/snippet_011_nim.sh` — sh (1 lines)

  - `Chapter_10/snippet_012.nim` — nim (47 lines)

  - `Chapter_10/snippet_013.nim` — nim (10 lines)

  - `Chapter_10/snippet_014.txt` — txt (7 lines)

  - `Chapter_10/snippet_015.txt` — txt (1 lines)

  - `Chapter_10/snippet_016.txt` — txt (1 lines)

  - `Chapter_10/snippet_017.txt` — txt (8 lines)

  - `Chapter_10/snippet_018.nim` — nim (40 lines)

- **Chapter 11** (16 snippets)

  - `Chapter_11/snippet_001.nim` — nim (2 lines)

  - `Chapter_11/snippet_002.nim` — nim (3 lines)

  - `Chapter_11/snippet_003.txt` — txt (1 lines)

  - `Chapter_11/snippet_004.nim` — nim (2 lines)

  - `Chapter_11/snippet_005.nim` — nim (2 lines)

  - `Chapter_11/snippet_006.nim` — nim (2 lines)

  - `Chapter_11/snippet_007_echo.nim` — nim (1 lines)

  - `Chapter_11/snippet_008.txt` — txt (1 lines)

  - `Chapter_11/snippet_009.nim` — nim (4 lines)

  - `Chapter_11/snippet_010.nim` — nim (4 lines)

  - `Chapter_11/snippet_011.nim` — nim (1 lines)

  - `Chapter_11/snippet_012.nim` — nim (5 lines)

  - `Chapter_11/snippet_013.nim` — nim (2 lines)

  - `Chapter_11/snippet_014.nim` — nim (1 lines)

  - `Chapter_11/snippet_015.nim` — nim (2 lines)

  - `Chapter_11/snippet_016.nim` — nim (3 lines)

- **Chapter 12** (23 snippets)

  - `Chapter_12/snippet_001_proc.nim` — nim (5 lines)

  - `Chapter_12/snippet_002.nim` — nim (4 lines)

  - `Chapter_12/snippet_003.sh` — sh (5 lines)

  - `Chapter_12/snippet_004.sh` — sh (1 lines)

  - `Chapter_12/snippet_005.nim` — nim (1 lines)

  - `Chapter_12/snippet_006.txt` — txt (6 lines)

  - `Chapter_12/snippet_007_proc.nim` — nim (2 lines)

  - `Chapter_12/snippet_008_proc.nim` — nim (2 lines)

  - `Chapter_12/snippet_009.nim` — nim (3 lines)

  - `Chapter_12/snippet_010_nim.sh` — sh (1 lines)

  - `Chapter_12/snippet_011.txt` — txt (4 lines)

  - `Chapter_12/snippet_012.sh` — sh (2 lines)

  - `Chapter_12/snippet_013.txt` — txt (1 lines)

  - `Chapter_12/snippet_014.nim` — nim (3 lines)

  - `Chapter_12/snippet_015.nim` — nim (4 lines)

  - `Chapter_12/snippet_016.txt` — txt (3 lines)

  - `Chapter_12/snippet_017.nim` — nim (19 lines)

  - `Chapter_12/snippet_018_proc.nim` — nim (5 lines)

  - `Chapter_12/snippet_019.nim` — nim (3 lines)

  - `Chapter_12/snippet_020.nim` — nim (3 lines)

  - `Chapter_12/snippet_021_nim.sh` — sh (2 lines)

  - `Chapter_12/snippet_022.nim` — nim (1 lines)

  - `Chapter_12/snippet_023.txt` — txt (1 lines)

- **FrontMatter** (12 snippets)

  - `FrontMatter/snippet_001.txt` — txt (1 lines)

  - `FrontMatter/snippet_002.txt` — txt (1 lines)

  - `FrontMatter/snippet_003.txt` — txt (1 lines)

  - `FrontMatter/snippet_004.txt` — txt (1 lines)

  - `FrontMatter/snippet_005.txt` — txt (1 lines)

  - `FrontMatter/snippet_006.txt` — txt (1 lines)

  - `FrontMatter/snippet_007_echo.nim` — nim (1 lines)

  - `FrontMatter/snippet_008_nim.sh` — sh (1 lines)

  - `FrontMatter/snippet_009_proc.nim` — nim (1 lines)

  - `FrontMatter/snippet_010.nim` — nim (2 lines)

  - `FrontMatter/snippet_011.txt` — txt (1 lines)

  - `FrontMatter/snippet_012.txt` — txt (1 lines)


## Notes
- Heuristic extraction: paragraphs styled as code or matching common Nim/CLI/C patterns.
- Some command-line examples are saved as `.sh` or `.bat`.
- If you want different grouping or filenames, tell me and I’ll regenerate.
