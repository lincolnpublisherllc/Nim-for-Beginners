nim c -r todo.nim
