nim compile hello.nim
