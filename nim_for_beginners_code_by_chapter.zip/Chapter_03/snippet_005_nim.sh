nim compile --run hello.nim
