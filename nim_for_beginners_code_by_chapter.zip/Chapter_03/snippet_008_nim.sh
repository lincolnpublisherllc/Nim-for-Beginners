nim c -d:release hello.nim
