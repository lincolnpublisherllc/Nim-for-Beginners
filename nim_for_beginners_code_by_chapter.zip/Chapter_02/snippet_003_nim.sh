nim --version
