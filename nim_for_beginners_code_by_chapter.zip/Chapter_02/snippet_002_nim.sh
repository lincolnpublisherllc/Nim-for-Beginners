nim --version
If installed correctly, you’ll see something like:
Nim Compiler Version 2.0.0 [MacOSX: arm64]
