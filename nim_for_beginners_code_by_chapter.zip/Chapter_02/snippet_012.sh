nimble install regex
