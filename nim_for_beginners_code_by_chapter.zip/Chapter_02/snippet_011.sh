nimble install cligen
Nimble will download, compile, and link it. Once done, you can use it in your own projects.
