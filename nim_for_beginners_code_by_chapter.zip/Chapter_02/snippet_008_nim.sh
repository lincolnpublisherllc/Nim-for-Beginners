nim compile --run check.nim
If you see:
Nim is installed!
