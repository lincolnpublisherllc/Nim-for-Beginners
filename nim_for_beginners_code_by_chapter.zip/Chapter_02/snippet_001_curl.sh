curl https://nim-lang.org/choosenim/init.sh -sSf | sh
