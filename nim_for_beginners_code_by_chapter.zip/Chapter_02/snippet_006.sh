choosenim update self
