Nimble comes pre-installed, but let’s check:
nimble --version
