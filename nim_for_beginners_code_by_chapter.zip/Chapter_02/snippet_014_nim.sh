nim compile --run regex_test.nim
