nim compile --run first.nim
If everything is set up, you’ll see:
Learning Nim is fun!
