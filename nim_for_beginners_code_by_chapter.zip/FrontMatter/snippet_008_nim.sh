nim c -r hello.nim
