choosenim update self
choosenim stable
