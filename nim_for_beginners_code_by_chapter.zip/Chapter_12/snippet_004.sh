nimble install cligen
