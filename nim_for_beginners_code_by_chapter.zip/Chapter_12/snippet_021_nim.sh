nim c -d:debug program.nim
nim c --debugger:native program.nim
