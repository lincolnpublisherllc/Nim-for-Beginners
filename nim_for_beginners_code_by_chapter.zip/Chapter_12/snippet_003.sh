Nim comes with a rich standard library. You’ve already used tables, strutils, and times. Importing is simple:
import strutils, math

echo "HELLO".toLower()
echo sqrt(25.0)
