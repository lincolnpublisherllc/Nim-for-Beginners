nim doc mymath.nim
