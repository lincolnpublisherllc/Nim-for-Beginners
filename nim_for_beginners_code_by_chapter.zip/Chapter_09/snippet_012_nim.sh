nim c --debugger:native -d:debug divide_error.nim
./divide_error
