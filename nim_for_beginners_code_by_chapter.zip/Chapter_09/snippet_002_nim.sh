nim c age_test.nim
