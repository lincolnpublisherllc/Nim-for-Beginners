nim c -r divide_error.nim
