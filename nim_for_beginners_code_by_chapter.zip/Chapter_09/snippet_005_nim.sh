nim c -r runtime_error.nim
