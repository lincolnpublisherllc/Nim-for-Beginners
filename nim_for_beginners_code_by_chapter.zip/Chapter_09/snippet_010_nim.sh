nim c -d:debug divide_error.nim
